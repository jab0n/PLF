# PROGR.LOG.FUNC-EJ2025-1S7A
Repositorio de código del curso de programación lógica y funcional 
